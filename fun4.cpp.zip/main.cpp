/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
int large(int a,int b,int c);
int small(int x,int y,int z);
int main()
{
    int n1,n2,n3,s,l;
    cout<<"Enter the number";
    cin>>n1>>n2>>n3;
    l=large(n1,n2,n3);
    s=small(n1,n2,n3);
    cout<<"Largest no is:"<<l;
    cout<<"Smallest no is:"<<s;
}
int large(int a,int b,int c)
{
    if(a>b)
    {
        if(a>c)
        {
          return a;
        }
        else
    {
            return c;
    }
    }
    else if(b>c) 
     return b; 
     else
     return c;
}
int small(int x,int y,int z)
{
    if(x<y)
    {
    if(x<z)
    return x;
    else
    return z;
    }
else if(y<z)
return y;
else
return z;
}